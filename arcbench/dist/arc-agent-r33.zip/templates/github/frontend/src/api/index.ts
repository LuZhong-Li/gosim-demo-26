import axios from 'axios';

export type User = { username: string; email: string; emailVerified: boolean };
export type Org = {
  name: string;
  displayName: string;
  /** REQ-3-2-2: the signed-in user's role in the organization, when known. */
  role?: string | null;
};
export type Repo = {
  owner: string;
  name: string;
  visibility: string;
  description: string;
  defaultBranch?: string;
  ownerType?: string;
  cloneUrl?: string;
  forkedFrom?: string | null;
  /** REQ-3-4 / REQ-6-1: whether the signed-in user may manage repository settings. */
  canAdmin?: boolean;
  /** REQ-4-3-2: whether the signed-in user may create branches. */
  canWrite?: boolean;
  /** REQ-6-1: the persisted branch protection rule, if one exists. */
  protection?: { branch: string; requiredApprovals: number; requiredChecks: string[] };
};
export type Issue = {
  number: number;
  title: string;
  body?: string;
  author: string;
  state: string;
  createdAt: string;
  comments?: Comment[];
  assignee?: string | null;
  assignees?: string[];
  labels?: string[];
  milestone?: string | null;
  reactions?: Reaction[];
  updatedAt?: string;
  activities?: { type: string; actor: string; at: string; body?: string }[];
  /** REQ-5-2-2 / REQ-5-4: permission flags for the issue detail view. */
  canEdit?: boolean;
  canClose?: boolean;
  /** REQ-5-3-3: Triage+ may change the milestone. */
  canTriage?: boolean;
};
export type Reaction = { user: string; type: string; commentId?: string | null };
export type Comment = {
  id: string;
  author: string;
  body: string;
  createdAt: string;
};
export type Review = {
  id: string;
  author: string;
  state: string;
  body: string;
  createdAt: string;
};
export type PullRequest = {
  number: number;
  title: string;
  body?: string;
  author: string;
  state: string;
  baseBranch: string;
  headBranch: string;
  createdAt: string;
  reviews?: Review[];
  checks?: { name: string; state: string; setBy?: string; setAt?: string; headSha?: string }[];
  reviewers?: ReviewerRequest[];
  mergedBy?: string;
  mergedAt?: string;
  mergeCommit?: string;
  mergeMethod?: string;
  milestone?: string | null;
  /** REQ-6-3-1: ordinary conversation comments. */
  comments?: { id: string; author: string; body: string; createdAt?: string }[];
  /** REQ-6-2-3 / REQ-6-6: pull request activity records. */
  activities?: { type: string; actor: string; at: string; body?: string }[];
};
export type PullDetail = {
  pull: PullRequest;
  protection: { branch: string; requiredApprovals: number; requiredChecks: string[] };
  approvals: number;
  canAdmin?: boolean;
  /** REQ-6-6: whether the signed-in user may close or reopen this PR. */
  canClose?: boolean;
  /** REQ-6-5: whether the signed-in user may merge this PR. */
  canMerge?: boolean;
  /** REQ-5-3-3: whether the signed-in user may change the milestone. */
  canTriage?: boolean;
  /** REQ-6-5: paths that conflict between the base and compare branches. */
  conflicts?: string[];
};
export type DiffLine = { type: string; text: string };
export type DiffFile = { path: string; status: string; lines: DiffLine[] };
export type PullFiles = {
  baseBranch: string;
  headBranch: string;
  files: DiffFile[];
  stats: { changedFiles: number; added: number; removed: number };
};
export type Team = {
  name: string;
  description: string;
  members: string[];
  parent?: string | null;
};
export type Member = { username: string; role: string };
export type OrgDetail = {
  org: Org;
  role: string | null;
  repos: Repo[];
  members: Member[];
  teams: Team[];
};
export type ApiError = { error: string };

const TOKEN_KEY = 'gh_token';

export const tokenStore = {
  get: (): string | null => {
    try {
      return window.localStorage.getItem(TOKEN_KEY);
    } catch {
      return null;
    }
  },
  set: (token: string): void => {
    try {
      window.localStorage.setItem(TOKEN_KEY, token);
    } catch {
      // ignore
    }
  },
  clear: (): void => {
    try {
      window.localStorage.removeItem(TOKEN_KEY);
    } catch {
      // ignore
    }
  },
};

const client = axios.create({ baseURL: '/api', timeout: 8000 });
client.interceptors.request.use((config) => {
  const token = tokenStore.get();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export async function register(input: {
  username: string;
  email: string;
  password: string;
  confirmPassword: string;
  terms: boolean;
}): Promise<{ user: User }> {
  const response = await client.post('/auth/register', input);
  return response.data;
}

export async function login(
  identifier: string,
  password: string,
): Promise<{ token: string; user: User }> {
  const response = await client.post('/auth/login', { identifier, password });
  return response.data;
}

export async function me(): Promise<User> {
  const response = await client.get('/auth/me');
  return response.data.user as User;
}

export async function logout(): Promise<void> {
  await client.post('/auth/logout');
}

export async function listOrgs(): Promise<Org[]> {
  const response = await client.get('/orgs');
  return response.data.orgs as Org[];
}

export async function createOrg(input: { name: string; displayName: string }): Promise<Org> {
  const response = await client.post('/orgs', input);
  return response.data.org as Org;
}

export async function getOrg(name: string): Promise<OrgDetail> {
  const response = await client.get(`/orgs/${encodeURIComponent(name)}`);
  return response.data;
}

export async function createOrgRepo(
  org: string,
  input: { name: string; visibility: string; description: string },
): Promise<Repo> {
  const response = await client.post(`/orgs/${encodeURIComponent(org)}/repos`, input);
  return response.data.repo as Repo;
}

export async function listRepos(): Promise<Repo[]> {
  const response = await client.get('/repos');
  return response.data.repos as Repo[];
}

export type CodeMatch = {
  path: string;
  line: number;
  snippet: string;
  branch: string;
  sha: string;
};

export type CodeSearchResult = {
  matches: CodeMatch[];
  branch: string;
  languages: string[];
};

// REQ-4-2-3: search code within the current repository, optionally scoped by
// path, language and branch.
export async function searchCode(
  owner: string,
  name: string,
  query: string,
  options: { path?: string; language?: string; branch?: string } = {},
): Promise<CodeSearchResult> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/search`,
    {
      params: {
        q: query,
        path: options.path || '',
        language: options.language || '',
        branch: options.branch || '',
      },
    },
  );
  return {
    matches: response.data.matches as CodeMatch[],
    branch: response.data.branch as string,
    languages: (response.data.languages as string[]) || [],
  };
}

export async function searchRepos(query: string): Promise<Repo[]> {
  const response = await client.get('/search', { params: { q: query } });
  return response.data.repos as Repo[];
}

export async function discover(): Promise<{ orgs: Org[]; repos: Repo[] }> {
  const response = await client.get('/discover');
  return response.data;
}

export async function getRepo(owner: string, name: string): Promise<{ repo: Repo }> {
  const response = await client.get(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}`);
  return response.data;
}

export async function listIssues(owner: string, name: string): Promise<Issue[]> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/issues`,
  );
  return response.data.issues as Issue[];
}

export async function createIssue(
  owner: string,
  name: string,
  input: { title: string; body: string; assignee?: string; labels?: string[]; milestone?: string },
): Promise<Issue> {
  const response = await client.post(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/issues`,
    input,
  );
  return response.data.issue as Issue;
}

export async function updateIssue(
  owner: string,
  name: string,
  number: number,
  input: {
    state?: string;
    title?: string;
    body?: string;
    assignee?: string | null;
    assignees?: string[];
    labels?: string[];
    milestone?: string | null;
  },
): Promise<Issue> {
  const response = await client.patch(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/issues/${number}`,
    input,
  );
  return response.data.issue as Issue;
}

export async function getTree(
  owner: string,
  name: string,
  branch?: string,
): Promise<{ branch: string; defaultBranch: string; files: string[]; branches: string[] }> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/tree`,
    { params: branch ? { branch } : {} },
  );
  return response.data;
}

export async function getFile(
  owner: string,
  name: string,
  filePath: string,
  branch?: string,
): Promise<{ path: string; content: string }> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/contents`,
    { params: branch ? { path: filePath, branch } : { path: filePath } },
  );
  return response.data;
}

export async function createFile(
  owner: string,
  name: string,
  filePath: string,
  input: { content: string; message: string; branch?: string },
): Promise<{ path: string; message: string }> {
  const response = await client.post(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/contents`,
    { ...input, path: filePath },
  );
  return response.data;
}

export async function deleteFile(
  owner: string,
  name: string,
  filePath: string,
  input: { message: string; branch?: string },
): Promise<{ deleted: string; sha: string }> {
  const response = await client.delete(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/contents`,
    { params: { path: filePath, ...input } },
  );
  return response.data;
}

export type BranchCompare = {
  base: string;
  head: string;
  same: boolean;
  hasDifference: boolean;
  commits: { sha: string; message: string; author: string; timestamp: string }[];
  files: { path: string; status: string; lines: { type: string; text: string }[] }[];
  stats: { changedFiles: number; added: number; removed: number };
};

export async function compareBranches(
  owner: string,
  name: string,
  base: string,
  head: string,
): Promise<BranchCompare> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/compare`,
    { params: { base, head } },
  );
  return response.data as BranchCompare;
}

export async function listCommits(
  owner: string,
  name: string,
  options: { path?: string } = {},
): Promise<{ sha: string; message: string; author: string; timestamp: string; changed: string[] }[]> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/commits`,
    { params: { path: options.path || '' } },
  );
  return response.data.commits;
}

export async function createBranch(
  owner: string,
  name: string,
  branchName: string,
): Promise<void> {
  await client.post(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/branches`, {
    name: branchName,
  });
}

export async function listPulls(owner: string, name: string): Promise<PullRequest[]> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls`,
  );
  return response.data.pulls as PullRequest[];
}

export async function createPull(
  owner: string,
  name: string,
  input: {
    title: string;
    body: string;
    baseBranch: string;
    headBranch: string;
    draft?: boolean;
  },
): Promise<PullRequest> {
  const response = await client.post(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls`,
    input,
  );
  return response.data.pull as PullRequest;
}

export async function getPull(owner: string, name: string, number: number): Promise<PullDetail> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${number}`,
  );
  return response.data;
}

// REQ-6-3-2: changed files and aggregate diff for the pull request.
export type ReviewComment = {
  id: string;
  author: string;
  path: string;
  line: number;
  body: string;
  state: string;
  outdated?: boolean;
  published?: boolean;
};

// REQ-6-3-3: inline review comments anchored to a file and line.
export type ReviewerRequest = { username: string; requestedBy?: string; createdAt?: string };

// REQ-6-4: request or remove a pull-request reviewer.
export type CommitDiff = {
  commit: { sha: string; message: string; author: string; timestamp: string };
  parentSha: string | null;
  files: DiffFile[];
  stats: { changedFiles: number; added: number; removed: number };
};

// REQ-4-2-2: diff introduced by a single commit.
export type AccessGrant = {
  repo: string;
  user?: string | null;
  team?: string | null;
  permission: string;
};

// REQ-2-3: grant repository access to a member or a team.
export async function grantRepoAccess(
  org: string,
  input: { repo: string; username?: string; team?: string; permission: string },
): Promise<AccessGrant> {
  const response = await client.post(`/orgs/${encodeURIComponent(org)}/access`, input);
  return response.data.grant as AccessGrant;
}

export async function getCommitDiff(
  owner: string,
  name: string,
  sha: string,
): Promise<CommitDiff> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/commits/${encodeURIComponent(sha)}`,
  );
  return response.data as CommitDiff;
}

export async function requestPullReviewer(
  owner: string,
  name: string,
  number: number,
  username: string,
): Promise<ReviewerRequest[]> {
  const response = await client.post(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${number}/reviewers`,
    { username },
  );
  return response.data.reviewers as ReviewerRequest[];
}

export async function removePullReviewer(
  owner: string,
  name: string,
  number: number,
  username: string,
): Promise<ReviewerRequest[]> {
  const response = await client.delete(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${number}/reviewers/${encodeURIComponent(username)}`,
  );
  return response.data.reviewers as ReviewerRequest[];
}

export async function getPullComments(
  owner: string,
  name: string,
  number: number,
): Promise<ReviewComment[]> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${number}/comments`,
  );
  return response.data.comments as ReviewComment[];
}

export async function addPullComment(
  owner: string,
  name: string,
  number: number,
  input: { path: string; line: number; body: string; pending?: boolean },
): Promise<ReviewComment> {
  const response = await client.post(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${number}/comments`,
    input,
  );
  return response.data.comment as ReviewComment;
}

// REQ-6-3-1: an ordinary Conversation comment carries no code location.
export async function addPullConversationComment(
  owner: string,
  name: string,
  number: number,
  body: string,
): Promise<{ id: string; author: string; body: string; createdAt?: string }> {
  const response = await client.post(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${number}/comments`,
    { body },
  );
  return response.data.comment;
}

export async function getPullFiles(
  owner: string,
  name: string,
  number: number,
): Promise<PullFiles> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${number}/files`,
  );
  return response.data as PullFiles;
}

export async function updatePullMilestone(
  owner: string,
  name: string,
  number: number,
  milestone: string,
): Promise<PullRequest> {
  const response = await client.patch(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${number}`,
    { milestone },
  );
  return response.data.pull as PullRequest;
}

export async function setPullState(
  owner: string,
  name: string,
  number: number,
  state: string,
): Promise<PullRequest> {
  const response = await client.patch(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${number}`,
    { state },
  );
  return response.data.pull as PullRequest;
}

export async function addPullReview(
  owner: string,
  name: string,
  number: number,
  input: { state: string; body: string },
): Promise<void> {
  await client.post(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${number}/reviews`,
    input,
  );
}

export async function addPullCheck(
  owner: string,
  name: string,
  number: number,
  checkName: string,
): Promise<void> {
  await setPullCheck(owner, name, number, checkName, 'success');
}

// REQ-6-1: the Checks area offers an Admin a status combobox and a Save button.
export async function setPullCheck(
  owner: string,
  name: string,
  number: number,
  checkName: string,
  state: string,
): Promise<void> {
  await client.post(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${number}/checks`,
    { name: checkName, state },
  );
}

export async function getBranchProtection(
  owner: string,
  name: string,
  branch: string,
): Promise<{ branch: string; requiredApprovals: number; requiredChecks: string[] }> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/branches/${encodeURIComponent(branch)}/protection`,
  );
  return response.data.protection;
}

export async function setBranchProtection(
  owner: string,
  name: string,
  branch: string,
  input: { requiredApprovals: number; requiredChecks: string[] },
): Promise<void> {
  await client.put(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/branches/${encodeURIComponent(branch)}/protection`,
    input,
  );
}

export async function mergePull(owner: string, name: string, number: number): Promise<PullRequest> {
  const response = await client.post(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${number}/merge`,
  );
  return response.data.pull as PullRequest;
}

export async function forgotPassword(email: string): Promise<{ code: string }> {
  const response = await client.post('/auth/forgot', { email });
  return response.data;
}

// REQ-6-3-1: commits on the PR's compare branch relative to its base.
export async function listPullCommits(
  owner: string,
  name: string,
  number: number,
): Promise<{
  baseBranch: string;
  headBranch: string;
  commits: { sha: string; message: string; author: string; timestamp: string }[];
  stats: { changedFiles: number; added: number; removed: number };
}> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${number}/commits`,
  );
  return response.data;
}

export async function resetPassword(input: {
  email: string;
  code: string;
  password: string;
  confirmPassword: string;
}): Promise<void> {
  await client.post('/auth/reset', input);
}

export async function addOrgMember(
  org: string,
  input: { username: string; role: string },
): Promise<Member> {
  const response = await client.post(`/orgs/${encodeURIComponent(org)}/members`, input);
  return response.data.member as Member;
}

export async function createTeam(
  org: string,
  input: { name: string; description: string },
): Promise<Team> {
  const response = await client.post(`/orgs/${encodeURIComponent(org)}/teams`, input);
  return response.data.team as Team;
}

// REQ-2-2-2: change a team's parent (server rejects cycles).
export async function setTeamParent(
  org: string,
  team: string,
  parentTeam: string,
): Promise<Team> {
  const response = await client.patch(
    `/orgs/${encodeURIComponent(org)}/teams/${encodeURIComponent(team)}`,
    { parentTeam },
  );
  return response.data.team as Team;
}

// REQ-2-2-1 / REQ-2-2-2: the team detail page.
export async function getTeam(
  org: string,
  team: string,
): Promise<{ org: Org; team: Team; teams: string[]; role: string | null }> {
  const response = await client.get(
    `/orgs/${encodeURIComponent(org)}/teams/${encodeURIComponent(team)}`,
  );
  return response.data;
}

export async function addTeamMember(org: string, team: string, username: string): Promise<Team> {
  const response = await client.post(
    `/orgs/${encodeURIComponent(org)}/teams/${encodeURIComponent(team)}/members`,
    { username },
  );
  return response.data.team as Team;
}

export async function removeTeamMember(
  org: string,
  team: string,
  username: string,
): Promise<Team> {
  const response = await client.delete(
    `/orgs/${encodeURIComponent(org)}/teams/${encodeURIComponent(team)}/members/${encodeURIComponent(username)}`,
  );
  return response.data.team as Team;
}

export async function getIssue(owner: string, name: string, number: number): Promise<Issue> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/issues/${number}`,
  );
  return {
    ...(response.data.issue as Issue),
    canEdit: response.data.canEdit,
    canClose: response.data.canClose,
    canTriage: response.data.canTriage,
  };
}

// REQ-5-3-3: the selectable milestones of the current repository.
export async function listMilestones(owner: string, name: string): Promise<string[]> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/milestones`,
  );
  return response.data.milestones as string[];
}

// REQ-5-3-2: the label catalog of the current repository only.
export async function listLabels(owner: string, name: string): Promise<string[]> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/labels`,
  );
  return response.data.labels as string[];
}

// REQ-5-3-1: accounts that may be assigned to an issue (triage or higher).
export async function listRepoMembers(owner: string, name: string): Promise<string[]> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/members`,
  );
  return response.data.members as string[];
}

// REQ-2-3: repository Manage access.
export type RepoAccessGrant = { subject: string; kind: 'user' | 'team'; permission: string };

export async function getRepoAccess(
  owner: string,
  name: string,
): Promise<{
  canManage: boolean;
  grants: RepoAccessGrant[];
  members: string[];
  teams: string[];
}> {
  const response = await client.get(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/access`,
  );
  return response.data;
}

export async function setRepoAccess(
  owner: string,
  name: string,
  input: { subject: string; kind: 'user' | 'team'; permission: string },
): Promise<RepoAccessGrant> {
  const response = await client.post(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/access`,
    input,
  );
  const grant = response.data.grant as AccessGrant;
  return {
    subject: grant.user || grant.team || '',
    kind: grant.user ? 'user' : 'team',
    permission: grant.permission,
  };
}

export async function setIssueState(
  owner: string,
  name: string,
  number: number,
  state: string,
): Promise<Issue> {
  const response = await client.patch(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/issues/${number}`,
    { state },
  );
  return response.data.issue as Issue;
}

export async function addIssueComment(
  owner: string,
  name: string,
  number: number,
  body: string,
): Promise<Comment> {
  const response = await client.post(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/issues/${number}/comments`,
    { body },
  );
  return response.data.comment as Comment;
}

// REQ-5-2-3: toggle a 👍 reaction on an issue or one of its comments.
export async function toggleIssueReaction(
  owner: string,
  name: string,
  number: number,
  input: { type?: string; commentId?: string | null } = {},
): Promise<Issue> {
  const response = await client.post(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/issues/${number}/reactions`,
    input,
  );
  return response.data.issue as Issue;
}

// REQ-3-4 / REQ-4-3-3: repository settings updates (visibility, default branch).
export async function updateRepo(
  owner: string,
  name: string,
  input: { visibility?: string; defaultBranch?: string },
): Promise<Repo> {
  const response = await client.patch(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}`, input);
  return response.data.repo as Repo;
}

export async function setRepoVisibility(
  owner: string,
  name: string,
  visibility: string,
): Promise<Repo> {
  return updateRepo(owner, name, { visibility });
}

// REQ-1-3: change the current account password.
// REQ-3-2-1: create a repository in the current personal namespace.
export async function createPersonalRepo(input: {
  owner?: string;
  name: string;
  visibility: string;
  description?: string;
  readme?: boolean;
}): Promise<Repo> {
  const response = await client.post('/repos', input);
  return response.data.repo as Repo;
}

export async function changePassword(input: {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}): Promise<void> {
  await client.post('/auth/password', input);
}

// REQ-2-2-4: remove a member (and their team memberships) from an organization.
export async function removeOrgMember(org: string, username: string): Promise<void> {
  await client.delete(
    `/orgs/${encodeURIComponent(org)}/members/${encodeURIComponent(username)}`,
  );
}

// REQ-3-2-2: fork a repository into the current account or an owned organization.
export async function forkRepo(
  owner: string,
  name: string,
  input: { name?: string; targetOwner?: string; visibility?: string } = {},
): Promise<Repo> {
  const response = await client.post(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/fork`,
    input,
  );
  return response.data.repo as Repo;
}

// REQ-6-2-4: mark a draft pull request as ready for review.
export async function markPullReady(
  owner: string,
  name: string,
  number: number,
): Promise<PullRequest> {
  const response = await client.patch(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${number}`,
    { ready: true },
  );
  return response.data.pull as PullRequest;
}

export function errorMessage(error: unknown, fallback = 'Something went wrong.'): string {
  if (axios.isAxiosError(error)) {
    const payload = error.response?.data as ApiError | undefined;
    if (payload && payload.error) return payload.error;
  }
  return fallback;
}
